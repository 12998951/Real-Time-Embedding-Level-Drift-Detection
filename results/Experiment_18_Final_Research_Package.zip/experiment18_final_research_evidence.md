# Experiment 18 — Final Research Evidence Package

## 1. Experiment Overview

- Dataset: LFW filtered subset
- Model: InceptionResnetV1
- Pretrained weights: VGGFace2
- Embedding dimension: 512
- Brightness factors: 0.5, 1.0, 1.5
- Paired images: 889
- Evaluation identities: 13

## 2. Dataset Composition

The paired cohort contains 889 images from
13 identities.

Identity 14 contributes
504 images (56.7%).

| Identity | Paired image count |
|---:|---:|
| 1 | 33 |
| 2 | 21 |
| 8 | 24 |
| 12 | 114 |
| 13 | 21 |
| 14 | 504 |
| 33 | 22 |
| 36 | 19 |
| 43 | 18 |
| 45 | 29 |
| 47 | 22 |
| 49 | 22 |
| 60 | 40 |

## 3. Embedding Displacement

| Statistic | Low illumination | High illumination |
|---|---:|---:|
| Mean | 0.234665304 | 0.318513930 |
| Median | 0.222675174 | 0.306733727 |
| Standard deviation | 0.064857408 | 0.119036496 |

Mean high-minus-low displacement:
0.083848625

Median high-minus-low displacement:
0.075521380

Displacement reproduction maximum absolute error:
- Low: 0.0
- High: 0.0

## 4. Displacement Statistical Tests

| Analysis | Unit | n | Wilcoxon statistic | p-value |
|---|---|---:|---:|---:|
| Image-level | Paired images | 889 | 52705.0 | 4.708938281282196e-80 |
| Identity-level means | Identities | 13 | 3.0 | 0.001220703125 |
| Identity-level medians | Identities | 13 | 3.0 | 0.001220703125 |

The image-level analysis does not account for within-identity
clustering. It must not be interpreted as evidence from 889
independent subjects.

## 5. Aggregate Detector Results

        Condition  Euclidean  Mahalanobis
         Original   0.053114     0.797920
 Low illumination   0.094771     1.735851
High illumination   0.082996     1.871540

## 6. Identity-Level Detector Results

 Identity         Condition  Sample Count  Euclidean  Mahalanobis
        1  Low illumination            33   0.149250     2.782339
        1 High illumination            33   0.148628     2.664454
        2  Low illumination            21   0.114252     2.218929
        2 High illumination            21   0.156381     3.425386
        8  Low illumination            24   0.090153     1.767673
        8 High illumination            24   0.163730     3.398382
       12  Low illumination           114   0.099975     2.088854
       12 High illumination           114   0.147049     2.687828
       13  Low illumination            21   0.096684     1.858877
       13 High illumination            21   0.109598     2.416870
       14  Low illumination           504   0.115949     2.237119
       14 High illumination           504   0.126145     2.361648
       33  Low illumination            22   0.122249     2.349817
       33 High illumination            22   0.104505     2.485387
       36  Low illumination            19   0.087475     1.606887
       36 High illumination            19   0.060025     1.310032
       43  Low illumination            18   0.144286     2.689855
       43 High illumination            18   0.121999     2.462569
       45  Low illumination            29   0.105561     1.969325
       45 High illumination            29   0.145425     2.919845
       47  Low illumination            22   0.160491     2.826315
       47 High illumination            22   0.108598     2.301073
       49  Low illumination            22   0.099548     1.957867
       49 High illumination            22   0.124670     2.514419
       60  Low illumination            40   0.109205     2.321189
       60 High illumination            40   0.113700     2.590513

## 7. Detector Statistical Tests and Effect Sizes

| Detector | Wilcoxon statistic | p-value | Cohen's dz | Mean difference | Mean CI | Median difference | Median CI |
|---|---:|---:|---:|---:|---|---:|---|
| Euclidean | 32.0 | 0.375732 | 0.296882 | 0.010414 | [-0.007691, 0.028794] | 0.010196 | [-0.017744, 0.039864] |
| Mahalanobis | 18.0 | 0.057373 | 0.596839 | 0.374105 | [0.060047, 0.711013] | 0.269324 | [-0.117885, 0.598975] |

Neither paired detector-response Wilcoxon test reached the
0.05 significance threshold.

The Mahalanobis mean confidence interval and paired Wilcoxon
result should be reported together. They do not support a simple
claim of statistically significant detector change.

## 8. Identity-Level Detector Direction

- Euclidean high-versus-low response increased for 8 of 13
  identities and decreased for 5.
- Mahalanobis high-versus-low response increased for 9 of 13
  identities and decreased for 4.

## 9. Reproducibility Audit

Step 17.10.6.4: 54 checks passed; 0 failed.

The audit checked saved files, array shapes and integrity,
displacement reproduction, statistical summaries, CSV consistency,
metadata, and detector-table availability.

It did not independently rerun original image detection,
preprocessing, embedding extraction, or detector calibration.

## 10. Software Environment

| Component | Version |
|---|---|
| python | 3.13.18 |
| platform | Linux-6.6.159+-x86_64-with-glibc2.39 |
| numpy | 2.4.6 |
| pandas | 2.2.3 |
| scipy | 1.16.3 |
| pytorch | 2.14.1+cpu |
| torchvision | 0.29.1+cpu |
| scikit_learn | 1.6.1 |
| pillow | 11.3.0 |
| facenet_pytorch | 2.6.0 |

## 11. Evidence Classification

### Validated findings

- Saved embedding arrays and dimensions were verified.
- Saved illumination displacement arrays were reproduced exactly.
- Displacement summary statistics were reproduced.
- Image-level and identity-level displacement tests were reproduced.
- The saved identity summary CSV was checked for consistency.
- The reproducibility audit passed all 54 checks.

### Exploratory observations

- Aggregate Euclidean and Mahalanobis responses varied across
  illumination conditions.
- Detector response directions differed across identities.
- Paired detector-response tests did not reach the 0.05
  significance threshold.

### Claims not established

- Real-world biometric recognition accuracy.
- Generalisation to other datasets or models.
- Demographic fairness.
- Deployment readiness.
- Causal explanations for detector-response differences.

## 12. Limitations

1. The paired cohort contains 889 images from only 13 identities.
2. Identity 14 contributes 56.7% of the paired cohort.
3. The image-level test does not account for within-identity clustering.
4. Identity-level analyses have only 13 units.
5. The illumination conditions are controlled brightness transformations.
6. Detector-response findings rely on previously validated tables;
   this documentation step did not regenerate detector calibration
   or statistical tests.

## 13. Provenance and Scope

This evidence package consolidates previously generated and audited
Experiment 18 outputs.

It does not perform new image detection, preprocessing, embedding
extraction, model training, detector calibration, or statistical testing.

Original experiment archives and metadata are retained unchanged.
